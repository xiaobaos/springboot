package cn.mvapi.xiaobao.common.system.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 系统用户 前端控制器
 * </p>
 *
 * @author xiaobao
 * @since 2020-03-12
 */
@Controller
@RequestMapping("/sysUser")
public class SysUserController {

}
